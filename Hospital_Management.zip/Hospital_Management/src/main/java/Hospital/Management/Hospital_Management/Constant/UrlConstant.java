package Hospital.Management.Hospital_Management.Constant;

public class UrlConstant {

    public static final String BASE_URL = "/api";

    public static final String REGISTER = BASE_URL + "/register";
    public static final String LOGIN = BASE_URL + "/login";
    public static final String LOGOUT = BASE_URL + "/logout";
    public static final String ADD_PATIENT = BASE_URL + "/add/patient";
    public static final String UPDATED_PATIENT =  BASE_URL + "/update/patient";

    public static final String GET_DISCHARGED_PATIENT = BASE_URL + "/get/discharged-patient";
    public static final String GET_ADMITTED_PATIENT = BASE_URL + "/get/admitted-patient";
    public static final String GET_ALL_PATIENT_DETAILS = BASE_URL + "/get/all/filter/patient-details";



    public static final String TOKEN_SECRET = "my secret token";


}
