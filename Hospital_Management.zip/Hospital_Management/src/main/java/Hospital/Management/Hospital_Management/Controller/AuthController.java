package Hospital.Management.Hospital_Management.Controller;

import Hospital.Management.Hospital_Management.Constant.UrlConstant;
import Hospital.Management.Hospital_Management.Dto.LoginDto;
import Hospital.Management.Hospital_Management.Dto.SignUpDto;
import Hospital.Management.Hospital_Management.Enums.ThrougnMedium;
import Hospital.Management.Hospital_Management.Model.AuthTokenDetails;
import Hospital.Management.Hospital_Management.Model.User;
import Hospital.Management.Hospital_Management.Service.AuthService;
import Hospital.Management.Hospital_Management.Service.UserService;
import Hospital.Management.Hospital_Management.Util.ResponseHandler;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Objects;

@RestController
public class AuthController {

    @Autowired
    AuthService authService;
    @Autowired
    UserService userService;

    @PostMapping(value = UrlConstant.REGISTER)
    public ResponseEntity<Object> registerSUser(@RequestBody SignUpDto signUpDto){
        User user = null;
        if(Objects.isNull(signUpDto.getEmail()) && Objects.isNull(signUpDto.getMobileNo())){
            return ResponseHandler.response(HttpStatus.BAD_REQUEST, true
                    , "For Registration email or mobile is compulsary");
        }
        boolean isPasswordSame = signUpDto.validatePassword(signUpDto.getPassword(), signUpDto.getConfirmPassword());
        if(!isPasswordSame){
            return ResponseHandler.response(HttpStatus.BAD_REQUEST, true
                    , "Password and Confirm Password should be same");
        }
        if(Objects.nonNull(signUpDto.getEmail())){
            user = userService.getByEmail(signUpDto.getEmail());
        }
        if(Objects.nonNull(signUpDto.getMobileNo())){
            user = userService.getByMobile(signUpDto.getMobileNo());
        }
        if(Objects.nonNull(user)){
            return ResponseHandler.response(HttpStatus.BAD_REQUEST, true
                    , "User is already register with us");
        }
        User savedUser = authService.register(signUpDto);
        if(Objects.nonNull(savedUser)){
            return ResponseHandler.response(HttpStatus.OK, false
                    , "User Register successfully");
        }else {
            return ResponseHandler.response(HttpStatus.BAD_REQUEST, true
                    , "Getting error in registration pls try after some time");
        }
    }

    @PutMapping(value = UrlConstant.LOGIN)
    public ResponseEntity<Object> login(@RequestBody LoginDto loginDto){
        if(Objects.isNull(loginDto.getEmail()) && Objects.isNull(loginDto.getMobileNo())){
            return ResponseHandler.response(HttpStatus.BAD_REQUEST, true
                    , "Email or mobile Can't be null");
        }
        User user;
        if(ThrougnMedium.EMAIL.toString().equals(loginDto.getThrough())){
            user = userService.getByEmail(loginDto.getEmail());
        } else if (ThrougnMedium.MOBILE.toString().equals(loginDto.getThrough())) {
            user = userService.getByMobile(loginDto.getMobileNo());
        }else {
            return ResponseHandler.response(HttpStatus.BAD_REQUEST, true
                    , "User is not register with us");
        }
        boolean isValidCredentials = authService.authenticateUserCredentials(loginDto.getPassword(), user);

        if(!isValidCredentials){
            return ResponseHandler.response(HttpStatus.BAD_REQUEST, true
                    , "Invalid credentials.");
        }
        if(user.isDeleted()){
            return ResponseHandler.response(HttpStatus.BAD_REQUEST, true
                    , "User is Deactivated");
        }
        AuthTokenDetails savedAuthToken = authService.login(user);
        if(Objects.nonNull(savedAuthToken)){
            return ResponseHandler.response(HttpStatus.OK, false
                    , "Login Successful", savedAuthToken.getAuthToken());
        }else {
            return ResponseHandler.response(HttpStatus.BAD_REQUEST, true
                    , "Getting error in login pls try after some time");
        }
    }

    @DeleteMapping(value = UrlConstant.LOGOUT)
    public ResponseEntity<Object> logout(@RequestHeader("authToken") String authToken){
        System.out.println(authToken);
        AuthTokenDetails authTokenDetails = authService.getAuthToken(authToken);
        if(Objects.nonNull(authTokenDetails)){
            authService.logout(authToken);
            return ResponseHandler.response(HttpStatus.OK, false
                    , "Logout Successful");
        }else {
            return ResponseHandler.response(HttpStatus.BAD_REQUEST, true
                    , "Getting error in logout pls try after some time");
        }
    }
}




