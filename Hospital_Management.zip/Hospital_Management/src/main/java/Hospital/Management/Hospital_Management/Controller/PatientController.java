package Hospital.Management.Hospital_Management.Controller;

import Hospital.Management.Hospital_Management.Constant.UrlConstant;
import Hospital.Management.Hospital_Management.Dto.AddPatientDto;
import Hospital.Management.Hospital_Management.Dto.GetPatientsDto;
import Hospital.Management.Hospital_Management.Dto.UpdatePatientDto;
import Hospital.Management.Hospital_Management.Enums.PatientStatus;
import Hospital.Management.Hospital_Management.Model.Patient;
import Hospital.Management.Hospital_Management.Service.AuthService;
import Hospital.Management.Hospital_Management.Service.PatientService;
import Hospital.Management.Hospital_Management.Util.ResponseHandler;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Objects;

@RestController
public class PatientController {

    @Autowired
    PatientService patientService;

    @Autowired
    AuthService authService;

    @PostMapping(value = UrlConstant.ADD_PATIENT)
    public ResponseEntity<Object> addPatient(@RequestBody AddPatientDto addPatientdto,
                                                   @RequestHeader("authToken") String authToken){
        Boolean isValidToken = authService.validateAuthToken(authToken);
        if(!isValidToken){
            return ResponseHandler.response(HttpStatus.BAD_REQUEST, true
                    , "Invalid auth token");
        }
        Patient patient = patientService.addPatient(addPatientdto);
        if(Objects.nonNull(patient)){
            return ResponseHandler.response(HttpStatus.OK, false
                    , "Patient Admit successfully");
        }else {
            return ResponseHandler.response(HttpStatus.BAD_REQUEST, true
                    , "Getting error in saving patient details pls try after some time");
        }
    }

    @PostMapping(value = UrlConstant.UPDATED_PATIENT)
    public ResponseEntity<Object> UpdatedPatient(@RequestBody UpdatePatientDto updatePatientDto,
                                             @RequestHeader("authToken") String authToken){
        Boolean isValidToken = authService.validateAuthToken(authToken);
        if(!isValidToken){
            return ResponseHandler.response(HttpStatus.BAD_REQUEST, true
                    , "Invalid auth token");
        }
        Patient patient = patientService.updatePatient(updatePatientDto);
        if(Objects.nonNull(patient)){
            return ResponseHandler.response(HttpStatus.OK, false
                    , "Patient Details updated successfully");
        }else {
            return ResponseHandler.response(HttpStatus.BAD_REQUEST, true
                    , "Getting error in saving patient details pls try after some time");
        }
    }

    @GetMapping(value = UrlConstant.GET_ADMITTED_PATIENT)
    public ResponseEntity<Object> getAdmittedPatient(@RequestHeader String authToken){
        Boolean isValidToken = authService.validateAuthToken(authToken);
        if(!isValidToken){
            return ResponseHandler.response(HttpStatus.BAD_REQUEST, true
                    , "Invalid auth token");
        }
        List<Patient> patientList = patientService.getPatient(PatientStatus.ADMITTED);
        if(Objects.isNull(patientList) || patientList.isEmpty()){
            return ResponseHandler.response(HttpStatus.BAD_REQUEST, true
                    , "Getting error in fetching patient details pls try after some time");
        }else {
            return ResponseHandler.response(HttpStatus.OK, false
                    , "Patient details fetched successfully",patientList);
        }
    }

    @GetMapping(value = UrlConstant.GET_DISCHARGED_PATIENT)
    public ResponseEntity<Object> getDischargedPatient(@RequestHeader String authToken){
        Boolean isValidToken = authService.validateAuthToken(authToken);
        if(!isValidToken){
            return ResponseHandler.response(HttpStatus.BAD_REQUEST, true
                    , "Invalid auth token");
        }
        List<Patient> patientList = patientService.getPatient(PatientStatus.DISCHARGED);
        if(Objects.isNull(patientList) || patientList.isEmpty()){
            return ResponseHandler.response(HttpStatus.BAD_REQUEST, true
                    , "Getting error in fetching patient details pls try after some time");
        }else {
            return ResponseHandler.response(HttpStatus.OK, false
                    , "Patient details fetched successfully",patientList);
        }
    }

    @PutMapping(value = UrlConstant.GET_ALL_PATIENT_DETAILS)
    public ResponseEntity<Object> getPatientDetails(@RequestBody GetPatientsDto getPatientsDto,
                                                    @RequestHeader String authToken){
        Boolean isValidToken = authService.validateAuthToken(authToken);
        if(!isValidToken){
            return ResponseHandler.response(HttpStatus.BAD_REQUEST, true
                    , "Invalid auth token");
        }
        Page<Patient> response = patientService.getFilterPatient(getPatientsDto);
        return ResponseHandler.response(HttpStatus.OK, false
                , "Patient details fetched successfully");
    }
}
