package Hospital.Management.Hospital_Management.Enums;

public enum PatientStatus {
    ADMITTED, DISCHARGED
}
