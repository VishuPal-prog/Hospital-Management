package Hospital.Management.Hospital_Management.Enums;

public enum ThrougnMedium {

    EMAIL, MOBILE;
}
