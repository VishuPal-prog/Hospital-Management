package Hospital.Management.Hospital_Management.Repo;

import Hospital.Management.Hospital_Management.Model.AuthTokenDetails;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface AuthTokenDetailsRepo extends JpaRepository<AuthTokenDetails, Long> {
    AuthTokenDetails findByAuthToken(String authToken);

    AuthTokenDetails findByUserId(Long id);
}
