package Hospital.Management.Hospital_Management.Repo;

import Hospital.Management.Hospital_Management.Enums.PatientStatus;
import Hospital.Management.Hospital_Management.Model.Patient;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface PatientRepo extends JpaRepository<Patient, Long>, JpaSpecificationExecutor<Patient> {
    List<Patient> findByPatientStatus(PatientStatus admitted);
}
