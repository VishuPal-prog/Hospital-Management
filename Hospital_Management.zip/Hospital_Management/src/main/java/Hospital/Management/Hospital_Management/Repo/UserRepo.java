package Hospital.Management.Hospital_Management.Repo;


import Hospital.Management.Hospital_Management.Model.User;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UserRepo extends JpaRepository<User, Long> {
    User findByEmail(String email);

    User findByMobileNo(String mobile);
}
