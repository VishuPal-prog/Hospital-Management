package Hospital.Management.Hospital_Management.Service;

import Hospital.Management.Hospital_Management.Dto.SignUpDto;
import Hospital.Management.Hospital_Management.Model.AuthTokenDetails;
import Hospital.Management.Hospital_Management.Model.User;
import Hospital.Management.Hospital_Management.Repo.AuthTokenDetailsRepo;
import Hospital.Management.Hospital_Management.Repo.UserRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Objects;
import java.util.UUID;

@Service
public class AuthService {
    @Autowired
    UserRepo userRepo;
    @Autowired
    AuthTokenDetailsRepo authTokenDetailsRepo;

    public User register(SignUpDto signUpDto) {
        User user = new User();
        user.setEmail(signUpDto.getEmail());
        user.setFullName(signUpDto.getFullName());
        user.setPassword(signUpDto.getPassword());
        user.setMobileNo(signUpDto.getMobileNo());
        return userRepo.save(user);
    }

    public boolean authenticateUserCredentials(String password, User user) {
        return password.equals(user.getPassword());
    }

    public AuthTokenDetails login(User user) {
        AuthTokenDetails authTokenDetails  = authTokenDetailsRepo.findByUserId(user.getId());
        if(Objects.nonNull(authTokenDetails)){
            authTokenDetailsRepo.delete(authTokenDetails);
        }
        String authToken = UUID.randomUUID().toString().concat("-"+user.getId());
//        System.out.println(authToken);
        authTokenDetails = new AuthTokenDetails();
        authTokenDetails.setUserId(user.getId());
        authTokenDetails.setAuthToken(authToken);
        return authTokenDetailsRepo.save(authTokenDetails);
    }

    public AuthTokenDetails getAuthToken(String authToken) {
        System.out.println(authToken);
        return authTokenDetailsRepo.findByAuthToken(authToken);
    }

    public void logout(String authToken) {
        AuthTokenDetails authTokenDetails = authTokenDetailsRepo.findByAuthToken(authToken);
        authTokenDetailsRepo.delete(authTokenDetails);
    }

    public Boolean validateAuthToken(String authToken) {
        AuthTokenDetails authTokenDetails = authTokenDetailsRepo.findByAuthToken(authToken);
        if(Objects.nonNull(authTokenDetails)){
            return true;
        }else {
            return false;
        }
    }

    public AuthTokenDetails getAuthTokenByUserId(Long userId) {
        return authTokenDetailsRepo.findByUserId(userId);
    }
}
