package Hospital.Management.Hospital_Management.Service;

import Hospital.Management.Hospital_Management.Dto.AddPatientDto;
import Hospital.Management.Hospital_Management.Dto.GetPatientsDto;
import Hospital.Management.Hospital_Management.Dto.UpdatePatientDto;
import Hospital.Management.Hospital_Management.Enums.PatientStatus;
import Hospital.Management.Hospital_Management.Model.Patient;
import Hospital.Management.Hospital_Management.Repo.PatientRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

@Service
public class PatientService {

    @Autowired
    PatientRepo patientRepo;
    public Patient addPatient(AddPatientDto addPatientDto){
        Patient patient = new Patient();
        patient.setPatientStatus(PatientStatus.ADMITTED);
        patient.setAge(addPatientDto.getAge());
        patient.setName(addPatientDto.getName());
        patient.setDoctorName(addPatientDto.getDoctorName());
        patient.setExpenses(addPatientDto.getExpenses());
        patient.setRoomNo(addPatientDto.getRoomNo());
        patient.setUserId(addPatientDto.getUserId());
        return patientRepo.save(patient);
    }

    public Patient updatePatient(UpdatePatientDto updatePatientDto) {
        Optional<Patient> optionalPatient = patientRepo.findById(updatePatientDto.getPatientId());
        Patient patient;
        if(optionalPatient.isPresent()){
            patient = optionalPatient.get();
        }else {
            return null;
        }
        if(updatePatientDto.getPatientStatus().equalsIgnoreCase(PatientStatus.ADMITTED.toString())){
            patient.setPatientStatus(PatientStatus.ADMITTED);
        }else {
            patient.setPatientStatus(PatientStatus.DISCHARGED);

        }
        if(Objects.nonNull(updatePatientDto.getAge())) {
            patient.setAge(updatePatientDto.getAge());
        }
        if(Objects.nonNull(updatePatientDto.getName())) {
            patient.setName(updatePatientDto.getName());
        }
        if(Objects.nonNull(updatePatientDto.getDoctorName())) {
            patient.setDoctorName(updatePatientDto.getDoctorName());
        }
        if(Objects.nonNull(updatePatientDto.getExpenses())) {
            patient.setExpenses(updatePatientDto.getExpenses());
        }
        if(Objects.nonNull(updatePatientDto.getRoomNo())) {
            patient.setRoomNo(updatePatientDto.getRoomNo());
        }

        return patientRepo.save(patient);
    }
    public List<Patient> getPatient(PatientStatus status) {
        return patientRepo.findByPatientStatus(status);
    }

    public Page<Patient> getFilterPatient(GetPatientsDto getPatientsDto) {
        Sort.Direction sort;
        if(getPatientsDto.getOrder().equalsIgnoreCase("asc")){
            sort = Sort.Direction.ASC;
        }else {
            sort = Sort.Direction.DESC;
        }
        if (Objects.isNull(getPatientsDto.getPageSize()) || getPatientsDto.getPageSize() <= 0) {
            getPatientsDto.setPageSize(10);
        }
        Pageable pageable = PageRequest.of(getPatientsDto.getPageNo()-1, getPatientsDto.getPageNo(),
                sort, getPatientsDto.getOrder());
        Specification<Patient> userSpecification = (root, query, cb) -> {
            List<Predicate> predicates = getFilters(getPatientsDto, root, cb);
            return cb.and(predicates.toArray(new javax.persistence.criteria.Predicate[0]));
        };
        return patientRepo.findAll(userSpecification, pageable);
    }

    private List<Predicate> getFilters(GetPatientsDto getPatientsDto, Root<Patient> root, CriteriaBuilder cb) {
        List<Predicate> predicates = new ArrayList<>();
        if(Objects.nonNull(getPatientsDto.getDoctorName()))
            predicates.add(cb.equal(root.get("doctorName"), getPatientsDto.getDoctorName()));
        if(Objects.nonNull(getPatientsDto.getName()))
            predicates.add(cb.equal(root.get("name"), getPatientsDto.getName()));
        if(Objects.nonNull(getPatientsDto.getStatus()))
            predicates.add(cb.equal(root.get("status"), getPatientsDto.getStatus()));
        return predicates;
    }


}
