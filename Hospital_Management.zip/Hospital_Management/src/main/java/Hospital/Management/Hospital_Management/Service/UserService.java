package Hospital.Management.Hospital_Management.Service;

import Hospital.Management.Hospital_Management.Model.User;
import Hospital.Management.Hospital_Management.Repo.UserRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class UserService {
    @Autowired
    UserRepo userRepo;
    public User getByEmail(String email) {
        return userRepo.findByEmail(email);
    }

    public User getByMobile(String mobile) {
        return userRepo.findByMobileNo(mobile);
    }

    public User getById(Long userId) {
        Optional<User> optionalUser = userRepo.findById(userId);
        if(optionalUser.isPresent()){
            return optionalUser.get();
        }else
            return null;
    }
}
