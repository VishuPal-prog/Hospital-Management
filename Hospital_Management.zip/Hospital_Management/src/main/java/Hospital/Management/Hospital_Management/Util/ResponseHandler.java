package Hospital.Management.Hospital_Management.Util;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;


public class ResponseHandler {
    public static ResponseEntity<Object> response(HttpStatus httpStatus, boolean isError , String msg) {
        Map<String, Object> response = new HashMap<>();
        response.put("timestamp", new Date().getTime());
        response.put("status", httpStatus.value());
        response.put("isError", isError);
        response.put("message", msg);
        return new ResponseEntity<>(response, httpStatus);
    }

    public static ResponseEntity<Object> response(HttpStatus httpStatus, boolean isError , String msg, Object responseObj) {
        Map<String, Object> response = new HashMap<>();
        response.put("timestamp", new Date().getTime());
        response.put("status", httpStatus.value());
        response.put("isError", isError);
        response.put("message", msg);
        response.put("responseObject", responseObj);
        return new ResponseEntity<>(response, httpStatus);
    }
}
